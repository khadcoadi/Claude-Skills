import azure.functions as func
import json
import os
import logging
import urllib.request
import urllib.error

app = func.FunctionApp()


@app.route(route="messages", auth_level=func.AuthLevel.ANONYMOUS, methods=["POST"])
def messages(req: func.HttpRequest) -> func.HttpResponse:
    try:
        body = req.get_json()
    except ValueError:
        return func.HttpResponse("Invalid JSON", status_code=400)

    logging.info(
        f"Activity: type={body.get('type')} "
        f"value_keys={list((body.get('value') or {}).keys())}"
    )

    value = body.get("value") or {}
    action = value.get("action")

    if action != "approve":
        return func.HttpResponse(status_code=200)

    push_payload = value.get("push_payload")
    if not push_payload:
        logging.warning("Approve clicked but no push_payload on submission")
        return func.HttpResponse(status_code=200)

    fire_url = os.environ.get("ROUTINE_FIRE_URL")
    bearer = os.environ.get("ROUTINE_BEARER_TOKEN")

    if not fire_url or not bearer:
        logging.error("Missing ROUTINE_FIRE_URL or ROUTINE_BEARER_TOKEN env vars")
        return func.HttpResponse("Server misconfigured", status_code=500)

    fire_body = json.dumps(
        {"text": push_payload if isinstance(push_payload, str) else json.dumps(push_payload)}
    ).encode()

    fire_req = urllib.request.Request(
        fire_url,
        data=fire_body,
        method="POST",
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {bearer}",
        },
    )

    try:
        with urllib.request.urlopen(fire_req, timeout=30) as r:
            logging.info(f"Routine fired: HTTP {r.status}")
    except urllib.error.HTTPError as e:
        logging.error(f"Routine fire failed: HTTP {e.code}: {e.read()[:300]}")
        return func.HttpResponse("Fire failed", status_code=500)

    return func.HttpResponse(status_code=200)
